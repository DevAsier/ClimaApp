// Añadimos un evento al botón 'getWeather' que se ejecutará cuando se haga clic
document.getElementById('getWeather').addEventListener('click', function() {
    const city = document.getElementById('city').value; // Obtenemos el valor de la ciudad que el usuario ha introducido en el campo de texto
    const apiKey = 'c833efad60c05758d6cbcd4b75245979';  // Definimos nuestra clave de API de OpenWeather
    const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric&lang=es`; //Definimos la URL de la API de OpenWeather

    // Realizamos una solicitud HTTP a la API utilizando fetch
    fetch(url)
        .then(response => {
            // Si la respuesta no es correcta (por ejemplo, la ciudad no existe), lanzamos un error
            if (!response.ok) {
                throw new Error('Ciudad no encontrada 🚫');
            }
            // Si la respuesta es válida, la convertimos en formato JSON
            return response.json();
        })
        .then(data => {
            // Obtenemos el contenedor donde mostraremos el resultado
            const weatherResult = document.getElementById('weatherResult');

            // Extraemos la temperatura, la descripción del clima y el nombre de la ciudad de la respuesta de la API
            const temp = data.main.temp;
            const description = data.weather[0].description;
            const city = data.name; 

            // Definimos un emoji que representará el clima según la descripción
            let emoji;
            if (description.includes("claro")) {
                emoji = "☀️"; // Soleado
            } else if (description.includes("nubes")) {
                emoji = "☁️"; // Nublado
            } else if (description.includes("nuboso")) {
                emoji = "☁️"; // Nuboso
            } else if (description.includes("lluvia")) {
                emoji = "🌧️"; // Lluvia
            } else if (description.includes("nieve")) {
                emoji = "❄️"; // Nieve
            } else if (description.includes("niebla")) {
                emoji = "🌫️"; // Niebla
            } else {
                emoji = "🌈"; // Otros tipos de clima
            }

            // Mostramos el resultado en el HTML, incluyendo la ciudad, la temperatura y la descripción
            weatherResult.innerHTML = 
                `<h2>Clima en ${city} ${emoji}</h2>
                <p>Temperatura: ${temp} °C</p>
                <p>Descripción: ${description} ${emoji}</p>`;
        })
        .catch(error => {
            // Si hay algún error (como no encontrar la ciudad o problemas con la API), mostramos el mensaje de error
            document.getElementById('weatherResult').innerHTML = `<p>${error.message}</p>`;
        });
});
